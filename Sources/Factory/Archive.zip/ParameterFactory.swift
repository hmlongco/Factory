//
//  Factory.swift
//  Factory
//
//  Created by Michael Long on 1/15/23.
//

import Foundation

/// Factory capable of taking parameters at runtime
public struct ParameterFactory<P,T>: FactoryModifing {

    /// Initializes a factory capable of taking parameters at runtime.
    /// ```swift
    /// var parameterService: ParameterFactory<Int, ParameterService> {
    ///     ParameterFactory(self) { ParameterService(value: $0) }
    /// }
    /// ```
    public init(_ container: SharedContainer, key: String = #function, _ factory: @escaping (P) -> T) {
        self.registration = FactoryRegistration<P,T>(id: "\(container.self).\(key)", container: container, factory: factory)
    }

    /// Resolves a factory capable of taking parameters at runtime.
    /// ```swift
    /// let service = container.parameterService(16)
    /// ```
    public func callAsFunction(_ parameters: P) -> T {
        registration.container.manager.resolve(registration, with: parameters)
    }

    /// Registers a new factory capable of taking parameters at runtime.
    /// ```swift
    /// container.parameterService.register { n in
    ///     ParameterService(value: n)
    /// }
    /// ```
    public func register(factory: @escaping (P) -> T) {
        registration.container.manager.register(id: registration.id, factory: TypedFactory<P,T>(factory: factory))
    }

    /// Required registration
    public var registration: FactoryRegistration<P,T>

}
