//
//  SharerdContainer.swift
//  FactoryDemo
//
//  Created by Michael Long on 2/4/23.
//

import Foundation

/// Containers are used by Factory to manage object creation, object resolution, and object lifecycles in general.
///
/// Registrations and scope caches will persist as long as the associated container remains in scope.
///
/// SharedContainer defines the protocol all Containers must adopt.
public protocol SharedContainer: AnyObject {

    /// Defines a single "shared" container for that container type.
    ///
    /// This container is used by the various @Injected property wrappers to resolve the keyPath to a given Factory. Care should be taken in
    /// mixed environments where you're passing container references AND using the @Injected property wrappers.
    static var shared: Self { get }

    /// Defines the ContainerManager used to manage registrations, resolutions, and scope caching for that container. Ecapsulating the code in
    /// this fashion makes creating and using your own custom containers much simpler.
    var manager: ContainerManager { get set }

}

/// Defines the default factory providers for containers
extension SharedContainer {

    /// Creates and returns a Factory struct associated with the current` container. The default scope is
    /// `unique` unless otherwise specified using a scope modifier.
    @inlinable public func makes<T>(key: String = #function, _ factory: @escaping () -> T) -> Factory<T> {
        Factory(self, key: key, factory)
    }

    /// Creates and returns a ParameterFactory struct associated with the current` container. The default scope is
    /// `unique` unless otherwise specified using a scope modifier.
    @inlinable public func makes<P,T>(key: String = #function, _ factory: @escaping (P) -> T) -> ParameterFactory<P,T> {
        ParameterFactory(self, key: key, factory)
    }

    /// Creates and returns a Factory struct associated with the current` container. The default scope is
    /// `unique` unless otherwise specified using a scope modifier.
    @inlinable public static func makes<T>(key: String = #function, _ factory: @escaping () -> T) -> Factory<T> {
        Factory(shared, key: key, factory)
    }

    /// Creates and returns a ParameterFactory struct associated with the current` container. The default scope is
    /// `unique` unless otherwise specified using a scope modifier.
    @inlinable public static func makes<P,T>(key: String = #function, _ factory: @escaping (P) -> T) -> ParameterFactory<P,T> {
        ParameterFactory(shared, key: key, factory)
    }

}

/// Addtional Support
extension SharedContainer {

    /// Defines a decorator for the container. This decorator will see every dependency resolved by this container.
    public func decorator(_ decorator: ((Any) -> ())?) {
        manager.decorator = decorator
    }

    /// Defines a with function to allow container transformation on assignment.
    @discardableResult
    public func with(_ transform: (Self) -> Void) -> Self {
        transform(self)
        return self
    }

}

