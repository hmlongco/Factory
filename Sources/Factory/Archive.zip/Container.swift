//
//  Container.swift
//  Factory
//
//  Created by Michael Long on 2/4/23.
//

import Foundation

/// Containers are used by Factory to manage object creation, object resolution, and object lifecycles in general.
///
/// Factory's are defined within container extensions, and must be provided with a reference to that container on
/// initialization.
/// ```swift
/// extension Container {
///     var service: Factory<ServiceType> {
///         Factory(self) { MyService() }
///     }
/// }
/// ```
/// Registrations and scope caches will persist as long as the associated container remains in scope.
///
/// This is the default Container provided for your convenience by Factory. If you'd like to define your own, use the
/// following as a template.
/// ```swift
/// public final class MyContainer: SharedContainer {
///      public static var shared = MyContainer()
///      public var manager = ContainerManager()
/// }
/// ```
public final class Container: SharedContainer {

    /// Define the default shared container.
    public static var shared = Container()

    /// Define the container's manager.
    public var manager: ContainerManager = ContainerManager()

    /// Public initializer
    public init() {}
    
}
