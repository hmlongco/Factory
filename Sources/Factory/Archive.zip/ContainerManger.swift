//
//  ContainerManger.swift
//  Factory
//
//  Created by Michael Long on 2/4/23.
//

import Foundation

/// ContainerManager encapsulates and manages the registration, resolution, and scope caching mechanisms for a given container.
public class ContainerManager {

    /// Public initializer
    public init() {}

    /// Resets the Container to its original state, removing all registrations and clearing all scope caches.
    public func reset(options: FactoryResetOptions = .all) {
        guard options != .none else {
            return
        }
        defer { globalRecursiveLock.unlock() }
        globalRecursiveLock.lock()
        switch options {
        case .registration:
            registrations = [:]
        case .scope:
            cache.reset()
        default:
            registrations = [:]
            cache.reset()
        }
    }

    /// Clears any cached values associated with a specific scope.
    public func reset(scope: Scope) {
        defer { globalRecursiveLock.unlock() }
        globalRecursiveLock.lock()
        cache.reset(scope: scope)
    }

    /// Test function pushes the current registration and cache states
    public func push() {
        defer { globalRecursiveLock.unlock() }
        globalRecursiveLock.lock()
        stack.append((registrations, cache.cache, autoRegistrationCheck))
    }

    /// Test function pops and restores a previously pushed registration and cache state
    public func pop() {
        defer { globalRecursiveLock.unlock() }
        globalRecursiveLock.lock()
        if let state = stack.popLast() {
            registrations = state.0
            cache.cache = state.1
            autoRegistrationCheck = state.2
        }
    }

    /// Support closure decorates all factory resolutions for this container.
    internal var decorator: ((Any) -> ())?

    // Internals
    internal typealias FactoryMap = [String:AnyFactory]
    internal var autoRegistrationCheck = true
    internal lazy var registrations: FactoryMap = .init(minimumCapacity: 32)
    internal lazy var cache: Scope.Cache = Scope.Cache()
    internal lazy var stack: [(FactoryMap, Scope.Cache.CacheMap, Bool)] = []
}


extension ContainerManager {

    /// Resolves a Factory, returning an instance of the desired type. All roads lead here.
    ///
    /// - Parameter factory: Factory wanting resolution.
    /// - Returns: Instance of the desired type.
    internal func resolve<P,T>(_ registration: FactoryRegistration<P,T>, with parameters: P) -> T {
        defer { globalRecursiveLock.unlock() }
        globalRecursiveLock.lock()

        if autoRegistrationCheck {
            (registration.container as? AutoRegistering)?.autoRegister()
            autoRegistrationCheck = false
        }

        let current: (P) -> T = (registrations[registration.id] as? TypedFactory<P,T>)?.factory ?? registration.factory

        #if DEBUG
        let typeComponents = String(reflecting: T.self).components(separatedBy: CharacterSet(charactersIn: "<>"))
        let typeName = typeComponents.count > 1 ? typeComponents[1] : typeComponents[0]
        let typeIndex = globalDependencyChain.firstIndex(where: { $0 == typeName })
        globalDependencyChain.append(typeName)
        if let index = typeIndex {
            let message = "circular dependency chain - \(globalDependencyChain[index...].joined(separator: " > "))"
            globalDependencyChain = []
            globalGraphResolutionDepth = 0
            globalRecursiveLock = NSRecursiveLock()
            triggerFatalError(message, #file, #line)
        }
        #endif

        // print("RESOLVING \(factory.id)")

        globalGraphResolutionDepth += 1
        let instance = registration.scope?.resolve(using: cache, id: registration.id, factory: { current(parameters) }) ?? current(parameters)
        globalGraphResolutionDepth -= 1

        if globalGraphResolutionDepth == 0 {
            Scope.graph.cache.reset()
        }

        #if DEBUG
        globalDependencyChain.removeLast()
        #endif

        registration.decorator?(instance)
        decorator?(instance)

        return instance
    }

    /// Registers a new factory closure capable of producing an object or service of the desired type. This factory overrides the original factory and
    /// the next time this factory is resolved Factory will evaluate the newly registered factory instead.
    /// - Parameters:
    ///   - id: ID of associated Factory.
    ///   - factory: Factory closure called to create a new instance of the service when needed.
    internal func register(id: String, factory: AnyFactory) {
        defer { globalRecursiveLock.unlock() }
        globalRecursiveLock.lock()
        registrations[id] = factory
        cache.removeValue(forKey: id)
    }

    /// Support function resets the behavior for a specific Factory to its original state, removing any assocatioed registraions and clearing
    /// any cached instances from the specified scope.
    /// - Parameters:
    ///   - options: Reset option: .all, .registration, .scope, .none
    ///   - id: ID of item to remove from the appropriate cache.
    internal func reset(options: FactoryResetOptions, for id: String) {
        guard options != .none else { return }
        defer { globalRecursiveLock.unlock() }
        globalRecursiveLock.lock()
        switch options {
        case .registration:
            registrations.removeValue(forKey: id)
        case .scope:
            cache.removeValue(forKey: id)
        default:
            registrations.removeValue(forKey: id)
            cache.removeValue(forKey: id)
        }
    }
 }

/// Master recursive lock
internal var globalRecursiveLock = NSRecursiveLock()

/// Master graph resolution depth counter
internal var globalGraphResolutionDepth = 0

#if DEBUG
/// Internal array used to check for circular dependency cycles
internal var globalDependencyChain: [String] = []
#endif

/// Add protocol to a container to support first-time registration of needed dependencies prior to first resolution on that container.
///
/// extension Container: AutoRegistering {
///     func autoRegister() {
///         someService.register {
///             CrossModuleService()
///         }
///     }
/// }
///
/// Note each instance of each container maintains its own autoRegistration state.
public protocol AutoRegistering {
    func autoRegister()
}

/// Reset options for Factory's and Container's
public enum FactoryResetOptions {
    case all
    case none
    case registration
    case scope
}

// Internal Factory type
internal protocol AnyFactory {
}

internal struct TypedFactory<P,T>: AnyFactory {
    let factory: (P) -> T
}

#if DEBUG
/// Allow unit test interception of any fatal errors that may occur running the circular dependency check
/// Variation of solution: https://stackoverflow.com/questions/32873212/unit-test-fatalerror-in-swift#
internal var triggerFatalError = Swift.fatalError
#endif

