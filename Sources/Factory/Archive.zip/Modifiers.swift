//
//  Modifiers.swift
//  Factory
//
//  Created by Michael Long on 2/4/23.
//

import Foundation

/// Internal protocol with functionality common to all Factory's. Used to add scope and decorator modifiers to Factory.
public protocol FactoryModifing {

    associatedtype P
    associatedtype T

    var registration: FactoryRegistration<P,T> { get set }
    
}

extension FactoryModifing {

    /// Defines Factory's dependency scope to be cached
    public var cached: Self {
        map { $0.registration.scope = .cached }
    }

    /// Defines Factory's dependency scope to be graph
    public var graph: Self {
        map { $0.registration.scope = .graph }
    }

    /// Defines Factory's dependency scope to be shared
    public var shared: Self {
        map { $0.registration.scope = .shared }
    }

    /// Defines Factory's dependency scope to be singleton
    public var singleton: Self {
        map { $0.registration.scope = .singleton }
    }

    /// Explictly defines unique scope
    public var unique: Self {
        map { $0.registration.scope = nil }
    }

    /// Defines a custom dependency scope for this Factory
    public func custom(scope: Scope?) -> Self {
        map { $0.registration.scope = scope }
    }

    /// Adds factory specific decorator
    public func decorator(_ decorator: @escaping (_ instance: T) -> Void) -> Self {
        map { $0.registration.decorator = decorator }
    }

}

extension FactoryModifing {

    /// Resets the Factory's behavior to its original state, removing any registraions and clearing any cached items from the specified scope.
    /// - Parameter options: options description
    public func reset(_ options: FactoryResetOptions = .all) {
        registration.container.manager.reset(options: options, for: registration.id)
    }

}

extension FactoryModifing {

    /// Allows builder-style mutation of self
    internal func map (_ mutate: (inout Self) -> Void) -> Self {
        var mutable = self
        mutate(&mutable)
        return mutable
    }

}
