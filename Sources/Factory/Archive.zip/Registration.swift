//
//  Registration.swift
//  Factory
//
//  Created by Michael Long on 2/4/23.
//

import Foundation

/// Shared registration type for Factory and ParameterFactory. Used internally to pass information from Factory to ContainerMaanger.
public struct FactoryRegistration<P,T> {
    /// Id used to manage registrations and cached values. Usually looks something like "MyApp.Container.service".
    internal var id: String
    /// A strong reference to the container supporting this Factory.
    internal var container: SharedContainer
    /// The originally registered factory closure used to produce an object of the desired type.
    internal var factory: (P) -> T
    /// The scope responsible for managing the lifecycle of any objects created by this Factory.
    internal var scope: Scope?
    /// Decorator will be passed fully constructed instance for further configuration.
    internal var decorator: ((T) -> Void)?
}
